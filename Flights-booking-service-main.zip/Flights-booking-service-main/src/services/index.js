module.exports = {
    BookingService : require('./booking-service')
}