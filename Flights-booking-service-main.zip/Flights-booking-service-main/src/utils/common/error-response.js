const error = {
    success: false,
    message: 'something went wrong',
    data: {},
    error: {}
}

module.exports = error;