const success = {
    success: true,
    message: 'successfully completed the request',
    data: {},
    error: {}
}

module.exports = success;