module.exports = {
    InfoController : require('./info_controller'),
    BookingController : require('./booking-controller')
}